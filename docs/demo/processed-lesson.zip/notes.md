# 最小二乘 · 公开自制示例

生成状态：已整理

[查看全部课件识别文字（本地原始识别）](ocr.txt)
[核对画面分组与所有出现记录](visuals.html)

## 线性最小二乘与正规方程

线性最小二乘用于在观测值不能由模型精确拟合时，寻找使残差平方和最小的参数。设设计矩阵为 $X\in\mathbb{R}^{m\times n}$，参数向量为 $w\in\mathbb{R}^{n}$，观测向量为 $y\in\mathbb{R}^{m}$，预测向量为 $Xw$。最小二乘目标函数定义为


$$
L(w)=\|y-Xw\|^2.
$$


平方误差同时惩罚正向和负向偏差。

对 $L(w)$ 关于 $w$ 求导并令其为零，可得正规方程


$$
X^{\mathsf T}(Xw-y)=0,
$$


等价地写作


$$
X^{\mathsf T}Xw=X^{\mathsf T}y.
$$


正规方程的几何含义是：残差 $r=y-Xw$ 与设计矩阵 $X$ 的每一列都正交，即 $X^{\mathsf T}r=0$。

当 $X$ 满列秩时，$X^{\mathsf T}X$ 可逆，最小二乘解唯一；满列秩要求 $m\ge n$ 且 $\operatorname{rank}(X)=n$。若 $X$ 不满列秩，最小二乘解仍然存在，但参数向量可能不唯一；此时不能把“解存在”与“参数唯一”混为一谈。

### 例：三点拟合直线

取


$$
X=\begin{bmatrix}1&0\\1&1\\1&2\end{bmatrix},\qquad
w=\begin{bmatrix}1\\2\end{bmatrix},\qquad
y=\begin{bmatrix}1\\3\\5\end{bmatrix}.
$$


这里第一列全为 $1$，对应截距；第二列对应斜率。计算得


$$
Xw=\begin{bmatrix}1\\3\\5\end{bmatrix}=y,
$$


三个观测值严格落在同一条直线上，残差为零。

现将第三个观测值由 $5$ 改为 $6$，即


$$
y=\begin{bmatrix}1\\3\\6\end{bmatrix}.
$$


此时三点不再严格共线。最小二乘解为


$$
\hat w=\begin{bmatrix}5/6\\5/2\end{bmatrix},
$$


即截距为 $5/6$，斜率为 $5/2$。对应残差为


$$
r=y-X\hat w=\begin{bmatrix}1/6\\-1/3\\1/6\end{bmatrix}.
$$


可以验证 $X^{\mathsf T}r=0$，残差与设计矩阵的两列都正交。

该例说明：残差非零表示没有精确拟合，并不表示最小二乘问题无解。最小二乘拟合向量 $X\hat w$ 是观测向量 $y$ 到设计矩阵列空间的正交投影；参数向量 $\hat w$ 本身不是该投影。即使残差非零，正规方程仍有解。注意：残差非零只说明 $y$ 不在 $X$ 的列空间中，并不排除 $X$ 不满列秩时参数不唯一的情形。

[查看课件来源](visuals.html#p00001) · [原始字幕](transcript.txt) · [识别修订记录](note_repairs.json)
